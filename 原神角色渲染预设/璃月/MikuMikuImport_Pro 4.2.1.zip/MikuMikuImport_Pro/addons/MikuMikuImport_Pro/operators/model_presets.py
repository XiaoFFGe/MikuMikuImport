import bpy
import os
import random


class modelOperator(bpy.types.Operator):
    '''Import MMD model presets'''
    bl_idname = "object.mmi_model_operator"
    bl_label = "Import model presets"

    # 确保在操作之前备份数据，用户撤销操作时可以恢复
    bl_options = {'REGISTER', 'UNDO'}

    # 打开文件选择器
    filepath: bpy.props.StringProperty(
        subtype='FILE_PATH',
    )
    filter_folder: bpy.props.BoolProperty(
        default=True,
        options={'HIDDEN'}
    )
    filter_blender: bpy.props.BoolProperty(
        default=True,
        options={'HIDDEN'}
    )

    def execute(self, context):
        def Additional_actions(A,B):
            # 指定要追加的集合的名称
            collection_name = A
            directory = B

            # 构建集合的完整路径
            full_filepath = os.path.join(self.filepath, directory, collection_name)
            # 执行追加操作
            bpy.ops.wm.append(
                filepath=full_filepath,
                directory=os.path.join(self.filepath, directory),
                filename=collection_name
            )

        # 追加集合
        Additional_actions('【MMD预设】','Collection')

        # 提取文件路径
        filename = self.filepath.split('/')[-1]
        print("选择的文件路径:", filename)
        filename = os.path.basename(filename)
        # 去掉扩展名
        filename, blend = os.path.splitext(filename)
        # 打印文件名
        print("选择的文件名称:", filename)

        # 遍历所有物体，选择名为"【MMD预设】"的物体
        for obj in bpy.data.objects:
            if obj.name == "【MMD预设】":
                obj.select_set(True)
                break  # 找到后退出循环

        # 激活所选的物体
        bpy.context.view_layer.objects.active = obj

        # 重置物体的可见性
        bpy.ops.mmd_tools.reset_object_visibility()

        if bpy.context.view_layer.objects.active is not None:
            # 生成一个随机数
            random_number = random.randint(1000, 9999)
            # 重命名当前活动的物体
            new_name = filename + ' ' + str(random_number)
            bpy.context.view_layer.objects.active.name = str(new_name)

            # 遍历所有当前选中的物体
        for obj in bpy.context.selected_objects:
            # 检查物体是否为Light类型，且光源类型为Sun
            if obj.type == 'LIGHT' and obj.data.type == 'SUN':
                # 确保该物体被选中
                obj.select_set(True)
                # 激活该物体，使其成为活动物体
                bpy.context.view_layer.objects.active = obj

        def rename_object_using_selected_object_name(source_obj_name, target_obj):
            # 获取当前选中的物体的名称
            source_obj = next((o for o in bpy.data.objects if o.name == source_obj_name), None)
            if source_obj:
                # 设置目标物体的名称为选中物体的名称
                target_obj.name = source_obj.name

        def rename_collection_to_selected_object_name(collection_name):
            # 获取当前选中的物体
            selected_object = bpy.context.view_layer.objects.active
            if selected_object is None:
                print("No object is currently selected.")
                return

            # 获取指定集合
            collection = bpy.data.collections.get(collection_name)
            if collection is None:
                print(f"Collection '{collection_name}' not found.")
                return

            # 重命名集合
            new_name = selected_object.name
            collection.name = new_name

            print(f"Collection '{collection_name}' renamed to '{new_name}'.")

        # 调用函数，将集合【MMD预设】的名称重命名为当前选中物体的名称
        rename_collection_to_selected_object_name("【MMD预设】")

        # 设置色彩空间
        bpy.context.scene.display_settings.display_device = 'sRGB'
        bpy.context.scene.view_settings.view_transform = 'Standard'
        bpy.context.scene.view_settings.look = 'None'

        return {'FINISHED'}

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}
