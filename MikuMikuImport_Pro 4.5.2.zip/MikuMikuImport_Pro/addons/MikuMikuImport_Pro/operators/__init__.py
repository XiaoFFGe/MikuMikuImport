mmi_object_name = {
    'MMI_AA':'MMI_Root',
    'MMI_AAA':'MMI_Arm',
    'MMI_AAAA':'MMI_Mesh',
    'MMI_AAAAA':'MMI_脸部定位'
}