import os
import re
import webbrowser

import bpy
from difflib import SequenceMatcher
from MikuMikuImport_Pro.addons.MikuMikuImport_Pro.config import __addon_name__
from MikuMikuImport_Pro.addons.MikuMikuImport_Pro.operators import mmi_object_name
from MikuMikuImport_Pro.addons.MikuMikuImport_Pro.operators.Local_search_engines import search_files


class MakePresetsOperator(bpy.types.Operator):
    '''Name the collection as [MMD Preset]'''
    bl_idname = "object.make_presets_ops"
    bl_label = "Name the collection you're in【MMD预设】"

    # 确保在操作之前备份数据，用户撤销操作时可以恢复
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: bpy.types.Context):
        return context.active_object is not None

    def execute(self, context):

        # 获取所有选中的物体
        selected_objects = bpy.context.selected_objects

        # 遍历选中的物体
        for obj in selected_objects:
            # 获取物体所属的所有集合
            collections = obj.users_collection

            # 遍历所有集合并打印和重命名
            if collections:
                for collection in collections:
                    print(f"物体 {obj.name} 所属集合的名称: {collection.name}")
                    self.report({'INFO'}, f"物体 {obj.name} 所属集合的名称: {collection.name}")

                    # 尝试重命名集合
                    if collection.name != "【MMD预设】":
                        try:
                            collection.name = "【MMD预设】"
                            print(f"集合已重命名为: {collection.name}")
                            self.report({'INFO'}, f"集合已重命名为: {collection.name}")
                        except Exception:
                            print(f"物体{obj.name}没有属于任何集合。")
                            self.report({'WARNING'}, f"物体 {obj.name} 没有属于任何集合。")

        return {'FINISHED'}

class MakePresets2Operator(bpy.types.Operator):
    '''Name the model'''
    bl_idname = "object.makess_presets_ops"
    bl_label = "Name the model"

    # 确保在操作之前备份数据，用户撤销操作时可以恢复
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: bpy.types.Context):
        if context.active_object is not None:
            if context.active_object.type == 'MESH':
                return True
        return False

    def execute(self, context):

        # 获取当前活动的物体
        active_object = bpy.context.active_object
        if active_object.name == mmi_object_name["MMI_AAAA"]:
            print('已经被命名了')
            self.report({'INFO'}, f"{active_object.name}已经被命名了")
        else:
            # 更改物体名称
            if active_object is not None:
                active_object.name = mmi_object_name["MMI_AAAA"]
                print(f"物体已重命名为 {mmi_object_name['MMI_AAAA']}")
                self.report({'INFO'}, f"已重命名为 {mmi_object_name['MMI_AAAA']}")

            else:
                print("没有活动的物体可以重命名。")

        return {'FINISHED'}


class MakePresets3Operator(bpy.types.Operator):
    '''Name the bones'''
    bl_idname = "object.maess_presets_ops"
    bl_label = "Name the bones"

    # 确保在操作之前备份数据，用户撤销操作时可以恢复
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: bpy.types.Context):
        if context.active_object is not None:
            if context.active_object.type == 'ARMATURE':
                return True
        return False

    def execute(self, context):

        # 获取当前活动的物体
        active_object = bpy.context.active_object
        if active_object.name == mmi_object_name["MMI_AAA"]:
            print('已经被命名了')
            self.report({'INFO'}, f"{active_object.name}已经被命名了")
        else:
            # 更改物体名称
            if active_object is not None:
                active_object.name = mmi_object_name["MMI_AAA"]
                print(f"物体已重命名为 {mmi_object_name['MMI_AAA']}")
            else:
                print("没有活动的物体可以重命名。")
        return {'FINISHED'}


class MakePresets4Operator(bpy.types.Operator):
    '''Name the SDF controller'''
    bl_idname = "object.maegss_presets_ops"
    bl_label = "Name the SDF controller"

    # 确保在操作之前备份数据，用户撤销操作时可以恢复
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: bpy.types.Context):
        if context.active_object is not None:
            if context.active_object.type == 'EMPTY':
                return True
        return False

    def execute(self, context):

        # 获取当前活动的物体
        active_object = bpy.context.active_object
        if active_object.name == mmi_object_name["MMI_AAAAA"]:
            print('已经被命名了')
            self.report({'INFO'}, f"{active_object.name}已经被命名了")
        else:
            # 更改物体名称
            if active_object is not None:
                active_object.name = mmi_object_name["MMI_AAAAA"]
                self.report({'INFO'}, f"已重命名为 {mmi_object_name['MMI_AAAAA']}")
            else:
                print("没有活动的物体可以重命名。")
        return {'FINISHED'}


class MakePresets6Operator(bpy.types.Operator):
    '''Name the MMD root object'''
    bl_idname = "object.mvaegs_ops"
    bl_label = "Name the MMD root object"

    # 确保在操作之前备份数据，用户撤销操作时可以恢复
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: bpy.types.Context):
        if context.active_object is not None:
            if context.active_object.type == 'EMPTY':
                return True
        return False

    def execute(self, context):

        # 获取活动物体名称
        active_object_name = context.active_object.name
        print('物体名称：', active_object_name)

        if active_object_name != mmi_object_name["MMI_AA"]:

            # 获取所有灯光类型的物体
            lights = [obj for obj in bpy.data.objects if obj.type == 'LIGHT']

            # 获取所有选中物体的名称（并清理标点符号）
            selected_objects_names = [re.sub(r'[^\w\s]', '', obj.name) for obj in bpy.context.selected_objects]

            # 重命名灯光物体
            for i, light in enumerate(lights):
                if i < len(selected_objects_names):
                    light.name = '__|【' + selected_objects_names[i] + "】|__"

            # 重命名物体
            bpy.data.objects.get(active_object_name)
            context.active_object.name = mmi_object_name["MMI_AA"]
        else:
            print('已经被命名了')
            self.report({'INFO'}, f"已经被命名了")

        return {'FINISHED'}


class MakePresets7Operator(bpy.types.Operator):
    """Separate models by map"""
    bl_idname = "object.makefdy_presets_ops"
    bl_label = "Separate models by map"

    # 确保在操作之前备份数据，用户撤销操作时可以恢复
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: bpy.types.Context):
        if context.active_object is not None:
            if context.active_object.type == 'MESH':
                return True
        return False

    def execute(self, context):

        # 调用操作
        bpy.ops.mmd_tools.convert_materials()
        bpy.ops.mmd_tools.separate_by_materials()

        # 创建一个字典来存储贴图名和对应的物体列表
        image_to_objects = {}

        # 获取当前选中的所有对象
        selected_objects = bpy.context.selected_objects

        # 遍历每个选中的对象
        for obj in selected_objects:
            # 获取对象的材质槽
            material_slots = obj.material_slots

            # 遍历每个材质槽
            for slot in material_slots:
                if slot.material:
                    material = slot.material
                    # 获取材质的节点树
                    node_tree = material.node_tree

                    # 遍历节点树中的所有节点
                    for node in node_tree.nodes:
                        if node.type == 'TEX_IMAGE':
                            # 获取图像纹理节点的图像
                            image = node.image
                            # 如果这个贴图已经在字典中，就将当前物体加入到对应的列表中
                            if image.name in image_to_objects:
                                image_to_objects[image.name].append(obj)
                            else:
                                # 否则，创建一个新的列表，并将当前物体加入
                                image_to_objects[image.name] = [obj]

        # 现在，image_to_objects字典包含了每张贴图对应的物体列表
        # 接下来，对每组使用相同贴图的物体进行合并

        for image_name, objects in image_to_objects.items():
            if len(objects) > 1:  # 只有当有多于一个物体时才需要合并
                # 选择第一个物体作为基础，其他物体将被合并到它上面
                base_obj = objects[0]
                # 构建要合并的物体列表
                merge_objects = objects[1:]

                # 合并物体
                bpy.ops.object.select_all(action='DESELECT')  # 先取消选择所有物体
                for obj in merge_objects:
                    obj.select_set(True)  # 选择要合并的物体
                base_obj.select_set(True)  # 最后选择基础物体
                bpy.context.view_layer.objects.active = base_obj  # 设置活动物体为base_obj

                # 执行合并操作
                bpy.ops.object.join()

        print("合并完成！")

        return {'FINISHED'}

class MakePresets9Operator(bpy.types.Operator):
    '''genshin presets'''
    bl_idname = "object.genshin_presets_ops"
    bl_label = "Hair/发"

    # 确保在操作之前备份数据，用户撤销操作时可以恢复
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):

        mmi = context.object.mmi

        def search_engine(i):
            keywords = str(i).split()
            file_paths = search_files(keywords, mmi.filepath)
            for path in file_paths:
                print(path)
                return path

        # 贴图路径
        NormalMap = search_engine('Hair Normal')
        Diffuse = search_engine('Hair Diffuse')
        Lightmap = search_engine('Hair Light map')
        Shadow_Ramp = search_engine('Hair Shadow_Ramp')

        # 获取当前活动对象的活动材质
        mat = bpy.context.object.active_material
        if mat and mat.node_tree:
            # 获取节点树中的所有节点
            nodes = mat.node_tree.nodes
            # 逐个删除节点
            for node in nodes:
                mat.node_tree.nodes.remove(node)

        def Connect_the_nodes(node1, 端口1, node2, 端口2):
            # 查找名为1和2的节点
            node_1 = None
            node_2 = None
            for node in mat.node_tree.nodes:
                if node.name == node1:
                    node_1 = node
                elif node.name == node2:
                    node_2 = node

            # 如果找到两个节点，则连接它们的端口
            if node_1 and node_2:
                output_socket = node_1.outputs.get(端口1)
                input_socket = node_2.inputs.get(端口2)
                if output_socket and input_socket:
                    mat.node_tree.links.new(output_socket, input_socket)

        # 创建材质输出节点
        output_node = mat.node_tree.nodes.new('ShaderNodeOutputMaterial')
        # 设置节点位置
        output_node.location = (200, 0)

        # 创建节点组
        Group_node = mat.node_tree.nodes.new('ShaderNodeGroup')
        Group_node.location = (0, 0)
        my_group = bpy.data.node_groups["髮"]
        Group_node.node_tree = my_group
        Group_node.name = "髮"

        # 连续节点
        Connect_the_nodes(Group_node.name, '颜色', output_node.name, 'Surface')

        # 访问节点组内的节点
        Group_node_list = Group_node.node_tree.nodes
        # ————————————————————————————————————————————————————————————————————————————————————————
        if Diffuse is not None:
            # 遍历节点列表来找到名称为Diffuse的节点：
            Diffuse_node = None
            for node in Group_node_list:
                if node.name == "Diffuse":
                    Diffuse_node = node
                    break
            # 修改节点
            if Diffuse_node:
                if Diffuse_node.image is None:
                    # 加载新的贴图
                    new_image = bpy.data.images.load(Diffuse)
                    # 替换贴图
                    Diffuse_node.image = new_image
                # 修改Alpha通道为通道打包
                Diffuse_node.image.alpha_mode = 'CHANNEL_PACKED'
        # ————————————————————————————————————————————————————————————————————————————
        if Lightmap is not None:
            # 遍历节点列表来找到名称为Lightmap的节点：
            Lightmap_node = None
            for node in Group_node_list:
                if node.name == "Lightmap":
                    Lightmap_node = node
                    break
            # 修改节点
            if Lightmap_node:
                if Lightmap_node.image is None:
                    # 加载新的贴图
                    new_image = bpy.data.images.load(Lightmap)
                    # 替换贴图
                    Lightmap_node.image = new_image
                # 修改Alpha通道为通道打包
                Lightmap_node.image.alpha_mode = 'CHANNEL_PACKED'
                # 将色彩空间设置为'Non - Color'
                Lightmap_node.image.colorspace_settings.name = 'Non-Color'
        # ————————————————————————————————————————————————————————————————————————————
        if Shadow_Ramp is not None:
            # 遍历节点列表来找到名称为Shadow_Ramp的节点：
            Shadow_Ramp_node = None
            for node in Group_node_list:
                if node.name == "Shadow_Ramp":
                    Shadow_Ramp_node = node
                    break
            # 修改节点
            if Shadow_Ramp_node:
                if Shadow_Ramp_node.image is None:
                    # 加载新的贴图
                    new_image = bpy.data.images.load(Shadow_Ramp)
                    # 替换贴图
                    Shadow_Ramp_node.image = new_image
        # ——————————————————————————————————————————————————————————————————————————————
        if NormalMap is not None:
            # 遍历节点列表来找到名称为Normal Map的节点：
            NormalMap_node = None
            for node in Group_node_list:
                if node.name == "Normal Map":
                    NormalMap_node = node
                    break
            # 修改节点
            if NormalMap_node:
                if NormalMap_node.image is None:
                    # 加载新的贴图
                    new_image = bpy.data.images.load(NormalMap)
                    # 替换贴图
                    NormalMap_node.image = new_image
                # 将色彩空间设置为'Non - Color'
                NormalMap_node.image.colorspace_settings.name = 'Non-Color'
        # ————————————————————————————————————————————————————————————————————————————————————————

        # 切换材质槽
        array = context.object.active_material_index
        context.object.active_material_index = array + 1
        bpy.context.object.active_material.preview_render_type = 'FLAT'
        return {'FINISHED'}

class MakePrehts9Operator(bpy.types.Operator):
    '''genshin presets'''
    bl_idname = "object.genshin_body_ops"
    bl_label = "Body/身体"

    # 确保在操作之前备份数据，用户撤销操作时可以恢复
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):

        mmi = context.object.mmi

        def search_engine(i):
            keywords = str(i).split()
            file_paths = search_files(keywords, mmi.filepath)
            for path in file_paths:
                print(path)
                return path

        # 贴图路径
        NormalMap = search_engine('Body Normal')
        Diffuse = search_engine('Body Diffuse')
        Lightmap = search_engine('Body Light map')
        Shadow_Ramp = search_engine('Body Shadow_Ramp')

        # 获取当前活动对象的活动材质
        mat = bpy.context.object.active_material
        if mat and mat.node_tree:
            # 获取节点树中的所有节点
            nodes = mat.node_tree.nodes
            # 逐个删除节点
            for node in nodes:
                mat.node_tree.nodes.remove(node)

        def Connect_the_nodes(node1, 端口1, node2, 端口2):
            # 查找名为1和2的节点
            node_1 = None
            node_2 = None
            for node in mat.node_tree.nodes:
                if node.name == node1:
                    node_1 = node
                elif node.name == node2:
                    node_2 = node

            # 如果找到两个节点，则连接它们的端口
            if node_1 and node_2:
                output_socket = node_1.outputs.get(端口1)
                input_socket = node_2.inputs.get(端口2)
                if output_socket and input_socket:
                    mat.node_tree.links.new(output_socket, input_socket)

        # 创建材质输出节点
        output_node = mat.node_tree.nodes.new('ShaderNodeOutputMaterial')
        # 设置节点位置
        output_node.location = (200, 0)

        # 创建节点组
        Group_node = mat.node_tree.nodes.new('ShaderNodeGroup')
        Group_node.location = (0, 0)
        my_group = bpy.data.node_groups["衣服"]
        Group_node.node_tree = my_group
        Group_node.name = "衣服"

        # 连续节点
        Connect_the_nodes(Group_node.name, '结果', output_node.name, 'Surface')

        # 访问节点组内的节点
        Group_node_list = Group_node.node_tree.nodes
        # ————————————————————————————————————————————————————————————————————————————————————————
        if Diffuse is not None:
            # 遍历节点列表来找到名称为Diffuse的节点：
            Diffuse_node = None
            for node in Group_node_list:
                if node.name == "Diffuse":
                    Diffuse_node = node
                    break
            # 修改节点
            if Diffuse_node:
                if Diffuse_node.image is None:
                    # 加载新的贴图
                    new_image = bpy.data.images.load(Diffuse)
                    # 替换贴图
                    Diffuse_node.image = new_image
                # 修改Alpha通道为通道打包
                Diffuse_node.image.alpha_mode = 'CHANNEL_PACKED'
        # ————————————————————————————————————————————————————————————————————————————
        if Lightmap is not None:
            # 遍历节点列表来找到名称为Lightmap的节点：
            Lightmap_node = None
            for node in Group_node_list:
                if node.name == "Lightmap":
                    Lightmap_node = node
                    break
            # 修改节点
            if Lightmap_node:
                if Lightmap_node.image is None:
                    # 加载新的贴图
                    new_image = bpy.data.images.load(Lightmap)
                    # 替换贴图
                    Lightmap_node.image = new_image
                # 修改Alpha通道为通道打包
                Lightmap_node.image.alpha_mode = 'CHANNEL_PACKED'
                # 将色彩空间设置为'Non - Color'
                Lightmap_node.image.colorspace_settings.name = 'Non-Color'
        # ————————————————————————————————————————————————————————————————————————————
        if Shadow_Ramp is not None:
            # 遍历节点列表来找到名称为Shadow_Ramp的节点：
            Shadow_Ramp_node = None
            for node in Group_node_list:
                if node.name == "Shadow_Ramp":
                    Shadow_Ramp_node = node
                    break
            # 修改节点
            if Shadow_Ramp_node:
                if Shadow_Ramp_node.image is None:
                    # 加载新的贴图
                    new_image = bpy.data.images.load(Shadow_Ramp)
                    # 替换贴图
                    Shadow_Ramp_node.image = new_image
        # ——————————————————————————————————————————————————————————————————————————————
        if NormalMap is not None:
            # 遍历节点列表来找到名称为Normal Map的节点：
            NormalMap_node = None
            for node in Group_node_list:
                if node.name == "Normal Map":
                    NormalMap_node = node
                    break
            # 修改节点
            if NormalMap_node:
                if NormalMap_node.image is None:
                    # 加载新的贴图
                    new_image = bpy.data.images.load(NormalMap)
                    # 替换贴图
                    NormalMap_node.image = new_image
                # 将色彩空间设置为'Non - Color'
                NormalMap_node.image.colorspace_settings.name = 'Non-Color'
        # ————————————————————————————————————————————————————————————————————————————————————————

        # 切换材质槽
        array = context.object.active_material_index
        context.object.active_material_index = array + 1
        bpy.context.object.active_material.preview_render_type = 'FLAT'
        return {'FINISHED'}

class MakePrehkhts9Operator(bpy.types.Operator):
    '''genshin presets'''
    bl_idname = "object.genshin_face_ops"
    bl_label = "Face/脸"

    # 确保在操作之前备份数据，用户撤销操作时可以恢复
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):

        mmi = context.object.mmi

        def search_engine(i):
            keywords = str(i).split()
            file_paths = search_files(keywords, mmi.filepath)
            for path in file_paths:
                print(path)
                return path

        # 贴图路径
        Diffuse = search_engine('Face Diffuse')
        if mmi.Face_Shadow_Ramp == 'Hair':
            Shadow_Ramp = search_engine('Hair Shadow_Ramp')
        else:
            Shadow_Ramp = search_engine('Body Shadow_Ramp')
        SDF = search_engine('Face Light map')

        # 获取当前活动对象的活动材质
        mat = bpy.context.object.active_material
        if mat and mat.node_tree:
            # 获取节点树中的所有节点
            nodes = mat.node_tree.nodes
            # 逐个删除节点
            for node in nodes:
                mat.node_tree.nodes.remove(node)

        def Connect_the_nodes(node1, 端口1, node2, 端口2):
            # 查找名为1和2的节点
            node_1 = None
            node_2 = None
            for node in mat.node_tree.nodes:
                if node.name == node1:
                    node_1 = node
                elif node.name == node2:
                    node_2 = node

            # 如果找到两个节点，则连接它们的端口
            if node_1 and node_2:
                output_socket = node_1.outputs.get(端口1)
                input_socket = node_2.inputs.get(端口2)
                if output_socket and input_socket:
                    mat.node_tree.links.new(output_socket, input_socket)

        # 创建材质输出节点
        output_node = mat.node_tree.nodes.new('ShaderNodeOutputMaterial')
        # 设置节点位置
        output_node.location = (200, 0)

        # 创建节点组
        Group_node = mat.node_tree.nodes.new('ShaderNodeGroup')
        Group_node.location = (0, 0)
        my_group = bpy.data.node_groups["颜"]
        Group_node.node_tree = my_group
        Group_node.name = "颜"

        # 连续节点
        Connect_the_nodes(Group_node.name, '结果', output_node.name, 'Surface')

        # 访问节点组内的节点
        Group_node_list = Group_node.node_tree.nodes
        # ——————————————————————————————————————————————————————————————————————
        if Diffuse is not None:
            # 遍历节点列表来找到名称为Diffuse的节点：
            Diffuse_node = None
            for node in Group_node_list:
                if node.name == "Diffuse":
                    Diffuse_node = node
                    break
            # 修改节点
            if Diffuse_node:
                if Diffuse_node.image is None:
                    # 加载新的贴图
                    new_image = bpy.data.images.load(Diffuse)
                    # 替换贴图
                    Diffuse_node.image = new_image
                # 修改Alpha通道为通道打包
                Diffuse_node.image.alpha_mode = 'CHANNEL_PACKED'
        # ——————————————————————————————————————————————————————————————————————
        if Shadow_Ramp is not None:
            # 遍历节点列表来找到名称为Shadow_Ramp的节点：
            Shadow_Ramp_node = None
            for node in Group_node_list:
                if node.name == "Shadow_Ramp":
                    Shadow_Ramp_node = node
                    break
            # 修改节点
            if Shadow_Ramp_node:
                if Shadow_Ramp_node.image is None:
                    # 加载新的贴图
                    new_image = bpy.data.images.load(Shadow_Ramp)
                    # 替换贴图
                    Shadow_Ramp_node.image = new_image
        # ——————————————————————————————————————————————————————————————————————

        # 遍历节点列表来找到名称为SDF的节点：
        SDF_node = None
        for node in Group_node_list:
            if node.name == "SDF":
                SDF_node = node
                break
        my_group = bpy.data.node_groups["SDF"]
        SDF_node.node_tree = my_group
        # 访问节点组内的节点
        SDF_Group_node_list = SDF_node.node_tree.nodes

        # ————————————————————————————————————————————————————————————
        if SDF is not None:
            # 遍历节点列表来找到名称为SDF的节点：
            SDF_node = None
            for node in SDF_Group_node_list:
                if node.name == "SDF":
                    SDF_node = node
                    break
            # 修改节点
            if SDF_node:
                if SDF_node.image is None:
                    # 加载新的贴图
                    new_image = bpy.data.images.load(SDF)
                    # 替换贴图
                    SDF_node.image = new_image
                # 将色彩空间设置为'Non-Color'
                SDF_node.image.colorspace_settings.name = 'Non-Color'

        # 切换材质槽
        array = context.object.active_material_index
        context.object.active_material_index = array + 1
        bpy.context.object.active_material.preview_render_type = 'FLAT'

        return {'FINISHED'}

class MakePrehtsManualOperator(bpy.types.Operator):
    '''genshin presets'''
    bl_idname = "object.genshin_manual_ops"
    bl_label = "Manual/手动"

    # 确保在操作之前备份数据，用户撤销操作时可以恢复
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):

        mmi = context.object.mmi

        def search_engine(i):
            keywords = str(i).split()
            file_paths = search_files(keywords, mmi.filepath)
            for path in file_paths:
                print(path)
                return path

        # 获取当前活动对象的活动材质
        mat = bpy.context.object.active_material
        if mat and mat.node_tree:
            # 获取节点树中的所有节点
            nodes = mat.node_tree.nodes
            # 逐个删除节点
            for node in nodes:
                mat.node_tree.nodes.remove(node)

        def Connect_the_nodes(node1, 端口1, node2, 端口2):
            # 查找名为1和2的节点
            node_1 = None
            node_2 = None
            for node in mat.node_tree.nodes:
                if node.name == node1:
                    node_1 = node
                elif node.name == node2:
                    node_2 = node

            # 如果找到两个节点，则连接它们的端口
            if node_1 and node_2:
                output_socket = node_1.outputs.get(端口1)
                input_socket = node_2.inputs.get(端口2)
                if output_socket and input_socket:
                    mat.node_tree.links.new(output_socket, input_socket)

        # 创建材质输出节点
        output_node = mat.node_tree.nodes.new('ShaderNodeOutputMaterial')
        # 设置节点位置
        output_node.location = (200, 0)

        # 创建节点组
        Group_node = mat.node_tree.nodes.new('ShaderNodeGroup')
        Group_node.location = (0, 0)
        my_group = bpy.data.node_groups["MMI节点"]
        Group_node.node_tree = my_group
        Group_node.name = "MMI节点"

        # 连续节点
        Connect_the_nodes(Group_node.name, '结果', output_node.name, 'Surface')

        # 切换材质槽
        array = context.object.active_material_index
        context.object.active_material_index = array + 1
        bpy.context.object.active_material.preview_render_type = 'FLAT'
        return {'FINISHED'}


class MakePrytyOperator(bpy.types.Operator):
    '''Load the node group'''
    bl_idname = "object.genshin_node_ops"
    bl_label = "Load the node group"

    # 确保在操作之前备份数据，用户撤销操作时可以恢复
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):

        Obj1 = context.active_object
        if Obj1.mmi.preset_Template == "":
            # 获取当前运行的Py文件的路径
            current_file_path = __file__
            # 获取当前Py文件所在的文件夹路径
            new_path = os.path.dirname(current_file_path)
            # 将当前文件夹路径和文件名组合成完整的文件路径
            file = 'bhp.blend'
            new_file_path = os.path.join(new_path, file)
            print(new_file_path)
        else:
            new_file_path = Obj1.mmi.preset_Template

        def Additional_actions(A, B, filepath):
            # 指定要追加的集合的名称
            collection_name = A
            directory = B

            # 构建集合的完整路径
            full_filepath = os.path.join(filepath, directory, collection_name)
            # 执行追加操作
            bpy.ops.wm.append(
                filepath=full_filepath,
                directory=os.path.join(filepath, directory),
                filename=collection_name
            )

        # 追加集合
        Additional_actions('MMI_一些东西', 'Collection', new_file_path)

        def delete_object(object_name):
            object_to_delete = bpy.data.objects.get(object_name)
            if object_to_delete is not None:
                bpy.context.view_layer.objects.active = object_to_delete
                # 遍历当前视图层中的所有物体
                for obj in bpy.context.view_layer.objects:
                    # 取消每个物体的选择状态
                    obj.select_set(False)
                # 将需要删除的物体设置为选中状态
                object_to_delete.select_set(True)
                # 执行删除物体的操作
                bpy.ops.object.delete()

        def delete_collection_and_move_to_parent(collection_name):
            target_coll = bpy.data.collections.get(collection_name)
            if not target_coll:
                print(f"集合 '{collection_name}' 不存在")
                return

            # 查找目标集合的所有父集合
            parent_collections = []
            for coll in bpy.data.collections:
                if target_coll.name in coll.children:
                    parent_collections.append(coll)

            # 如果目标集合没有父集合，默认转移到场景主集合
            if not parent_collections:
                parent_collections = [bpy.context.scene.collection]

            # 将对象和子集合转移到每个父集合
            for parent_coll in parent_collections:
                # 转移对象
                for obj in target_coll.objects[:]:  # 遍历副本避免修改问题
                    if obj.name not in parent_coll.objects:
                        parent_coll.objects.link(obj)
                    target_coll.objects.unlink(obj)

                # 转移子集合
                for child_coll in target_coll.children[:]:
                    if child_coll.name not in parent_coll.children:
                        parent_coll.children.link(child_coll)
                    target_coll.children.unlink(child_coll)

            # 解除目标集合的所有父级引用
            for coll in bpy.data.collections:
                if target_coll.name in coll.children:
                    coll.children.unlink(target_coll)

            # 删除目标集合
            bpy.data.collections.remove(target_coll)

        # 执行操作
        delete_collection_and_move_to_parent('MMI_一些东西')

        # 定义一个列表
        object_names = ["MMI_AAAA"]
        # 遍历物体名称列表，调用delete_object函数删除物体
        for object_name in object_names:
            delete_object(object_name)

        # 激活物体
        bpy.ops.object.select_all(action='DESELECT')
        bpy.context.view_layer.objects.active = Obj1
        # 选择物体
        Obj1.select_set(True)

        return {'FINISHED'}


class MakePres4Operator(bpy.types.Operator):
    '''Post-processing effect'''
    bl_idname = "object.maeg_ops"
    bl_label = "Post-processing effect"

    # 确保在操作之前备份数据，用户撤销操作时可以恢复
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):

        # 它遍历场景合成节点树中的所有节点，检查是否存在名称与传入参数相同的节点。如果存在则返回True，否则返回False。
        # Blender 5.2：Scene.node_tree 已移除，改用 Scene.compositing_node_group
        def node_exists(node_name):
            node_tree = bpy.context.scene.compositing_node_group
            if node_tree is None:
                return False
            for node in node_tree.nodes:
                if node.name == node_name:
                    return True
            return False

        # 如果这两个节点中的任何一个存在，就直接返回{'CANCELLED'}
        if node_exists('后期处理') or node_exists('边缘光深度'):
            return {'CANCELLED'}

        # 获取当前运行的Py文件的路径
        current_file_path = __file__
        # 获取当前Py文件所在的文件夹路径
        new_path = os.path.dirname(current_file_path)
        # 将当前文件夹路径和文件名组合成完整的文件路径
        file = 'bhp.blend'
        new_file_path = os.path.join(new_path, file)
        print(new_file_path)

        def Additional_actions(A, B, filepath):
            """ 追加集合操作 """
            # 指定要追加的集合的名称
            collection_name = A
            directory = B

            # 构建集合的完整路径
            full_filepath = os.path.join(filepath, directory, collection_name)
            # 执行追加操作
            bpy.ops.wm.append(
                filepath=full_filepath,
                directory=os.path.join(filepath, directory),
                filename=collection_name
            )

        # 设置色彩空间
        bpy.context.scene.display_settings.display_device = 'sRGB'
        bpy.context.scene.view_settings.view_transform = 'Standard'
        bpy.context.scene.view_settings.look = 'None'

        # 设置合成通道
        bpy.context.view_layer.use_pass_z = True
        view_layer = bpy.context.view_layer
        # AOV "边缘光数据" 是否存在
        if "边缘光数据" in view_layer.aovs:
            new_aov = view_layer.aovs["边缘光数据"]
        else:
            # 添加新的AOV
            bpy.ops.scene.view_layer_add_aov()
            new_aov = view_layer.aovs[-1]  # 新添加的AOV
            new_aov.name = "边缘光数据"

        bpy.context.area.ui_type = 'CompositorNodeTree'

        # Blender 5.2：use_nodes 已移除，合成节点树改为数据块（compositing_node_group）
        # 若场景还没有合成树，则新建一个并补齐基础的组输出、渲染层和查看器节点
        scene = bpy.context.scene
        node_tree = scene.compositing_node_group
        if node_tree is None: # 如果为空
            node_tree = bpy.data.node_groups.new(scene.name + " 合成", 'CompositorNodeTree')
            node_tree.use_fake_user = True
            # 新版合成树的最终输出由"组输出"节点决定，接口需先定义 Image 输出
            node_tree.interface.new_socket(name="Image", in_out='OUTPUT', socket_type="NodeSocketColor")
            group_output = node_tree.nodes.new('NodeGroupOutput')
            group_output.location = (400, 0)
            render_layers = node_tree.nodes.new('CompositorNodeRLayers')
            render_layers.location = (-400, 0)
            viewer = node_tree.nodes.new('CompositorNodeViewer')
            viewer.location = (400, -250)
            node_tree.links.new(render_layers.outputs['Image'], group_output.inputs['Image'])
            node_tree.links.new(render_layers.outputs['Image'], viewer.inputs['Image'])
            scene.compositing_node_group = node_tree

        # 追加节点组
        Additional_actions('后期处理', 'NodeTree', new_file_path)
        Additional_actions('边缘光深度', 'NodeTree', new_file_path)

        # 获取合成节点树
        scene = bpy.context.scene
        node_tree = scene.compositing_node_group

        # 遍历所有节点
        for node in node_tree.nodes:
            print(node.name, node.type)
            # 遍历所有节点的输入端口
            if node.inputs:
                for input in node.inputs:
                    print(f"节点 {node.name} 的输入端口 {input.name} 类型为 {input.type}")

            # 遍历所有节点的输出端口
            if node.outputs:
                for output in node.outputs:
                    print(f"节点 {node.name} 的输出端口 {output.name} 类型为 {output.type}")


        # 获取合成输出节点（Blender 5.2 移除了 Composite 节点，最终输出为组输出节点）
        output_node = None
        for node in node_tree.nodes:

            if node.type == 'GROUP_OUTPUT':
                output_node = node
                break

        if output_node:
            print("节点名称：", output_node.name)
        else:
            # 树里没有组输出节点：先补齐输出接口，再新建组输出节点
            if not any(s.in_out == 'OUTPUT' for s in node_tree.interface.items_tree):
                node_tree.interface.new_socket(name="Image", in_out='OUTPUT', socket_type="NodeSocketColor")
            output_node = node_tree.nodes.new('NodeGroupOutput')
            output_node.location = (400, 0)
            print("未找到组输出节点，已新建：", output_node.name)

        # 确保合成树接口包含 Image 颜色输出（组输出节点的输入端口会随接口自动同步）
        # 注意：不再添加Alpha输出接口，透明渲染改用"设置Alpha"节点处理
        if not any(s.in_out == 'OUTPUT' and s.socket_type == 'NodeSocketColor'
                   for s in node_tree.interface.items_tree):
            node_tree.interface.new_socket(name="Image", in_out='OUTPUT', socket_type="NodeSocketColor")

        # 解析组输出的图像输入端口：依次按英文名、中文名查找，最后回退到第一个RGBA颜色端口
        # 注意：不同来源的树（UI新建/旧版本升级）端口命名不一定是"Image"，
        # 若按固定名字查找会静默失败，导致最终输出没有接入后处理链
        output_image_input = output_node.inputs.get('Image')
        if output_image_input is None:
            output_image_input = output_node.inputs.get('图像')
        if output_image_input is None:
            for inp in output_node.inputs:
                if inp.type == 'RGBA':
                    output_image_input = inp
                    break
        if output_image_input is None and output_node.inputs:
            output_image_input = output_node.inputs[0]
        print("组输出图像输入端口：", output_image_input.name if output_image_input else None)

        def Connect_the_nodes(node1, 端口1, node2, 端口2):
            # 查找名为1和2的节点
            node_1 = None
            node_2 = None
            for node in node_tree.nodes:
                if node.name == node1:
                    node_1 = node
                elif node.name == node2:
                    node_2 = node

            # 如果找到两个节点，则连接它们的端口
            if node_1 and node_2:
                output_socket = node_1.outputs.get(端口1)
                input_socket = node_2.inputs.get(端口2)
                if output_socket and input_socket:
                    node_tree.links.new(output_socket, input_socket)

        #获取当前场景的渲染层节点名称
        def The_current_scene_rendernode():
            for node in bpy.context.scene.compositing_node_group.nodes:
                if node.type == 'R_LAYERS':
                    scene = node.scene
                    if scene and scene.name == bpy.context.scene.name:
                        print("当前场景的渲染层节点名称：", node.name)
                        return node.name

        # 确保存在当前场景的渲染层节点（场景已有节点树时可能缺失），缺失则新建
        render_node = The_current_scene_rendernode()
        if render_node is None:
            new_render_node = node_tree.nodes.new('CompositorNodeRLayers')
            new_render_node.location = (-400, 0)
            render_node = new_render_node.name
            print("未找到当前场景的渲染层节点，已新建：", render_node)

        # 获取预览器节点（场景已有节点树但缺少查看器时，新建一个，保证预览连线生效）
        preview_node = None
        for node in node_tree.nodes:

            if node.type == 'VIEWER':
                preview_node = node
                break

        if preview_node is None:
            preview_node = node_tree.nodes.new('CompositorNodeViewer')
            preview_node.location = (400, -250)
            print("未找到查看器节点，已新建：", preview_node.name)
        else:
            print("节点名称：", preview_node.name)

        # 获取组输出图像输入端口当前连接的来源节点及输出端口名（基于端口对象，不依赖端口命名）
        input_node = None
        print_node_output = None
        if output_image_input is not None:
            for link in output_image_input.links:
                input_node = link.from_node.name
                print_node_output = link.from_socket.name
                break
        if not input_node:
            # 组输出图像输入未连接时，改用渲染层作为图像来源
            input_node = render_node
            print_node_output = 'Image'
        print(f"连接到合成输出Image输入端口的节点：{input_node}")
        print(f"连接到合成输出Image输入端口的节点的输出端口名：{print_node_output}")

        # 创建节点组
        Group_node = node_tree.nodes.new('CompositorNodeGroup')
        Group_node.location = (0, 0)
        my_group = bpy.data.node_groups["后期处理"]
        Group_node.node_tree = my_group
        Group_node.name = "后期处理"

        Connect_the_nodes(input_node, print_node_output, "后期处理", 'Image')

        # 创建"设置Alpha"节点：把渲染层的Alpha应用到后处理结果上（对应旧版合成节点的Alpha输入）
        # Blender 5.2 的组输出没有独立的Alpha输入，需经Set Alpha节点合成才能保留透明背景
        set_alpha_node = None
        for node in node_tree.nodes:
            if node.type == 'SETALPHA':
                set_alpha_node = node
                break
        if set_alpha_node is None:
            set_alpha_node = node_tree.nodes.new('CompositorNodeSetAlpha')
            set_alpha_node.location = (250, -120)
            print("已新建设置Alpha节点：", set_alpha_node.name)
        # 必须设为"替换Alpha"模式：默认的"应用遮罩"是相乘模式，
        # 会保留后期处理输出的Bloom蒙版alpha而非渲染层的Alpha，导致透明背景失效
        type_socket = set_alpha_node.inputs.get('Type')
        if type_socket is not None:
            type_socket.default_value = 'Replace Alpha'

        # 后期处理 → 设置Alpha（图像）；渲染层Alpha → 设置Alpha；设置Alpha → 组输出（图像）
        if output_image_input is not None:
            pp_out = Group_node.outputs.get('Image')
            if pp_out is None:
                for o in Group_node.outputs:
                    if o.type == 'RGBA':
                        pp_out = o
                        break
            sa_img_in = set_alpha_node.inputs.get('Image')
            sa_img_out = set_alpha_node.outputs.get('Image')
            if pp_out and sa_img_in:
                node_tree.links.new(pp_out, sa_img_in)
            if sa_img_out:
                node_tree.links.new(sa_img_out, output_image_input)
        Connect_the_nodes(render_node, 'Alpha', set_alpha_node.name, 'Alpha')
        if preview_node:
                Connect_the_nodes("后期处理", 'Image', preview_node.name, 'Image')

        # 创建节点组
        Group_node = node_tree.nodes.new('CompositorNodeGroup')
        Group_node.location = (-200, 0)
        my_group = bpy.data.node_groups["边缘光深度"]
        Group_node.node_tree = my_group
        Group_node.name = "边缘光深度"

        Connect_the_nodes("边缘光深度", 'Image', "后期处理", 'Image')
        Connect_the_nodes(input_node, print_node_output, '边缘光深度', 'Image')
        Connect_the_nodes(render_node, 'Depth', '边缘光深度', 'Depth')
        Connect_the_nodes(render_node, "边缘光数据", "边缘光深度", "边缘光数据")

        bpy.context.area.ui_type = 'VIEW_3D'
        bpy.context.space_data.shading.use_compositor = 'ALWAYS'

        return {'FINISHED'}


class InvertthenormalsOperator(bpy.types.Operator):
    '''Invert the normals'''
    bl_idname = "object.make_normals_ops"
    bl_label = "Invert the normals"

    def execute(self, context):

        # 全局变量"i"
        i = None

        # 遍历选中的物体的材质槽，检查名称为衣服的节点是否存在
        # 获取选中的物体
        selected_objects = context.selected_objects

        found = False

        # 遍历选中的物体
        for obj in selected_objects:
            # 检查物体是否有材质槽
            if hasattr(obj, "material_slots"):
                # 遍历材质槽
                for material_slot in obj.material_slots:
                    # 获取材质
                    material = material_slot.material
                    # 检查材质是否使用节点
                    if material and material.use_nodes:
                        # 遍历节点树
                        for node in material.node_tree.nodes:
                            if found:
                                break
                            # 检查节点名称是否为“衣服”
                            if node.name == "衣服":
                                print(f"在物体 {obj.name} 的材质 {material.name} 中找到名为 '衣服' 的节点。")
                                body_node = node
                                found = True
                                # 获取节点组
                                my_group = bpy.data.node_groups["衣服"]
                                body_node.node_tree = my_group
                                # 访问节点组内的节点
                                Group_node_list = body_node.node_tree.nodes
                                # 遍历节点列表来找到名称为Invert Color的节点：
                                Invert_node = None
                                for node in Group_node_list:
                                    if node.name == "Invert Color":
                                        Invert_node = node
                                        break
                                i = Invert_node.inputs["Fac"].default_value
                                # 修改节点
                                if Invert_node:
                                    if i == 1:
                                        Invert_node.inputs["Fac"].default_value = 0
                                    else:
                                        Invert_node.inputs["Fac"].default_value = 1

        found = False
        # 遍历选中的物体
        for obj in selected_objects:
            # 检查物体是否有材质槽
            if hasattr(obj, "material_slots"):
                # 遍历材质槽
                for material_slot in obj.material_slots:
                    # 获取材质
                    material = material_slot.material
                    # 检查材质是否使用节点
                    if material and material.use_nodes:
                        # 遍历节点树
                        for node in material.node_tree.nodes:
                            if found:
                                break
                            # 检查节点名称是否为“髮”
                            if node.name == "髮":
                                print(f"在物体 {obj.name} 的材质 {material.name} 中找到名为 '髮' 的节点。")
                                body_node = node
                                found = True
                                # 获取节点组
                                my_group = bpy.data.node_groups["髮"]
                                body_node.node_tree = my_group
                                # 访问节点组内的节点
                                Group_node_list = body_node.node_tree.nodes
                                # 遍历节点列表来找到名称为Invert Color的节点：
                                Invert_node = None
                                for node in Group_node_list:
                                    if node.name == "Invert Color":
                                        Invert_node = node
                                        break
                                # 修改节点
                                if Invert_node:
                                    if i == 1:
                                        Invert_node.inputs["Fac"].default_value = 0
                                    else:
                                        Invert_node.inputs["Fac"].default_value = 1

        return {'FINISHED'}


class MakePrehOperator(bpy.types.Operator):
    '''Handle related objects with one click'''
    bl_idname = "object.mayyrh_presets_ops"
    bl_label = "Handle related objects with one click"

    # 确保在操作之前备份数据，用户撤销操作时可以恢复
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: bpy.types.Context):
        if context.active_object is not None:
            if context.active_object.type == "EMPTY":
                return True
        return False

    def execute(self, context):
        addon_prefs = context.preferences.addons[__addon_name__].preferences
        # 获取当前活动的物体
        active_object = bpy.context.active_object
        if active_object.name == mmi_object_name["MMI_AA"]:
            print('已经被命名了')
            self.report({'INFO'}, f"{active_object.name}已经被命名了")
        else:
            def delete_selected_child_rigidbodies(obj_name):
                # 获取当前选中物体
                selected_objs = bpy.context.selected_objects
                if not selected_objs:
                    print("错误：未选中任何物体")
                    return

                # 遍历所有选中物体
                for parent_obj in selected_objs:
                    # 查找直接子级中名为 obj_name 的物体
                    target_child = next((child for child in parent_obj.children
                                         if child.name == obj_name), None)

                    if not target_child:
                        print(f"'{parent_obj.name}' 的子级中未找到 rigidbodies")
                        continue

                    # 递归删除子级物体
                    def recursive_delete(obj):
                        # 先删除子物体（深度优先）
                        for child in obj.children:
                            recursive_delete(child)
                            print(f"删除子物体: {child.name}")
                            bpy.data.objects.remove(child, do_unlink=True)

                    recursive_delete(target_child)

                    # 删除目标物体本身
                    print(f"删除目标物体: {target_child.name}")
                    bpy.data.objects.remove(target_child, do_unlink=True)

                # 强制刷新大纲视图
                for area in bpy.context.window.screen.areas:
                    if area.type == 'OUTLINER':
                        area.tag_redraw()

            # 执行操作
            delete_selected_child_rigidbodies("rigidbodies")
            delete_selected_child_rigidbodies("joints")
            delete_selected_child_rigidbodies("temporary")

            # 更改物体名称
            if active_object is not None:
                # 命名根物体
                bpy.ops.object.mvaegs_ops()
                active_object = bpy.context.active_object
                # 取消全部选择
                bpy.ops.object.select_all(action='DESELECT')

                found = False
                # 遍历所有物体，查找名称包含'_mesh'的网格物体
                for obj in bpy.data.objects:
                    if obj.type == 'MESH' and '_mesh' in obj.name:
                        # 选中并激活物体
                        obj.select_set(True)
                        bpy.context.view_layer.objects.active = obj
                        # 执行操作
                        bpy.ops.object.makess_presets_ops()
                        # 取消选择
                        bpy.ops.object.select_all(action='DESELECT')
                        found = True
                        break

                # 如果未找到符合条件的物体
                if not found:
                    # 收集所有网格物体
                    mesh_objs = [obj for obj in bpy.data.objects if obj.type == 'MESH']
                    if mesh_objs:
                        # 选中所有网格物体
                        for obj in mesh_objs:
                            obj.select_set(True)
                            break
                        # 激活第一个网格物体
                        bpy.context.view_layer.objects.active = mesh_objs[0]
                        # 执行操作
                        bpy.ops.object.makess_presets_ops()
                        # 取消选择
                        bpy.ops.object.select_all(action='DESELECT')

                # 骨骼
                for obj in bpy.data.objects:
                    if obj.type == 'ARMATURE':
                        # 选中物体
                        obj.select_set(True)
                        # 激活物体
                        bpy.context.view_layer.objects.active = obj
                        # 执行操作
                        bpy.ops.object.maess_presets_ops()
                        # 检查定位骨骼
                        if obj and obj.type == 'ARMATURE' and obj.data.bones.get(addon_prefs.positioning_bone):
                            print(f"骨骼{addon_prefs.positioning_bone}存在")
                        else:
                            self.report({'WARNING'}, f"默认定位骨骼''{addon_prefs.positioning_bone}''不存在")

                        # 取消全部选择
                        bpy.ops.object.select_all(action='DESELECT')
                        break

                # SDF
                # 遍历所有物体，找到类型为 'EMPTY' 且名称里有 脸部定位 的物体
                for obj in bpy.data.objects:
                    if obj.type == 'EMPTY' and 'MMI_脸部定位' in obj.name:
                        # 选中物体
                        obj.select_set(True)
                        # 激活物体
                        bpy.context.view_layer.objects.active = obj
                        bpy.ops.object.maegss_presets_ops()
                        bpy.ops.object.mdts_preset_ops()
                        mmi = context.object.mmi
                        mmi.re_obj = True
                        # 旋转物体
                        obj.rotation_euler[0] = -90 * 3.1415926 / 180

                # Name the collection you're in【MMD预设】
                bpy.ops.object.make_presets_ops()

            else:
                print("没有活动的物体可以重命名。")

        # 打包资源
        bpy.ops.file.pack_all()

        return {'FINISHED'}


class MakePdtyOperator(bpy.types.Operator):
    '''Add a face positioning constraint'''
    bl_idname = "object.mdts_preset_ops"
    bl_label = "Add a face positioning constraint"

    # 确保在操作之前备份数据，用户撤销操作时可以恢复
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: bpy.types.Context):
        if context.active_object is not None:
            if context.active_object.type == 'EMPTY':
                return True
        return False

    def execute(self, context):
        addon_prefs = context.preferences.addons[__addon_name__].preferences
        # 获取当前活动的物体
        active_object = bpy.context.active_object
        # 清空所有约束
        active_object.constraints.clear()
        print(f"已删除物体 {active_object.name} 的所有约束")
        # 添加子级约束
        bpy.ops.object.constraint_add(type='CHILD_OF')
        # 获取刚刚添加的约束
        new_constraint = active_object.constraints[-1]
        # 设置约束
        new_constraint.name = '脸部定位-子级'
        new_constraint.target = bpy.data.objects[mmi_object_name["MMI_AAA"]]
        new_constraint.subtarget = addon_prefs.positioning_bone
        bpy.ops.constraint.childof_set_inverse(constraint="脸部定位-子级", owner='OBJECT')
        bpy.ops.constraint.childof_clear_inverse(constraint="脸部定位-子级", owner='OBJECT')
        # 清空位置
        bpy.ops.object.location_clear(clear_delta=False)

        return {'FINISHED'}

class MakePdtysOperator(bpy.types.Operator):
    '''return'''
    bl_idname = "object.mdtos_preset_ops"
    bl_label = "return"

    def execute(self, context):
        mmi = context.active_object.mmi
        mmi.re_obj = False
        return {'FINISHED'}

class Adaptivestrokes(bpy.types.Operator):
    '''Adaptive strokes'''
    bl_idname = "object.adaptive_strokes_ops"
    bl_label = "Add Adaptive strokes"
    # 确保在操作之前备份数据，用户撤销操作时可以恢复
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: bpy.types.Context):
        if context.active_object is not None:
            if context.active_object.type == 'MESH':
                return True
        return False

    def execute(self, context):

        mmi = context.object.mmi

        # 获取当前场景
        scene = bpy.context.scene

        def add_driver_to_solidify(A1,A2,A3,A4,A5,A6):
            # 获取当前激活的对象
            active_obj = bpy.context.active_object
            if not active_obj:
                print("当前没有激活的对象。")
                return

            # 尝试找到名为“自动描边”的实体化修改器，若没有则找第一个实体化修改器
            target_modifier = None
            block = False
            for modifier in active_obj.modifiers:
                if modifier.type == 'SOLIDIFY' and modifier.name == '自动描边':
                    target_modifier = modifier
                    break
            if not target_modifier:
                for modifier in active_obj.modifiers:
                    if modifier.type == 'SOLIDIFY':
                        target_modifier = modifier
                        break
            if not target_modifier:
                print("在激活对象中未找到实体化修改器,启动几何节点模式。")
                # 仅接受接口中含有“描边厚度”输入的几何节点修改器，
                # 避免误选模型上的其他几何节点修改器
                for modifier in active_obj.modifiers:
                    if modifier.type == 'NODES' and modifier.node_group:
                        if "描边厚度" in modifier.node_group.interface.items_tree:
                            block = True
                            target_modifier = modifier
                            break
                if not target_modifier:
                    print("在激活对象中未找到包含“描边厚度”输入的几何节点修改器。")
                    return

            # 几何节点模式：取得“描边厚度”输入对应的动态属性对象
            # Blender 5.2 起几何节点修改器输入不再是自定义属性（modifier["Input_1"]），
            # 需通过 modifier.properties.inputs.<标识符>.value 访问
            thickness_prop = None
            thickness_identifier = ""
            if block:
                thickness_identifier = target_modifier.node_group.interface.items_tree["描边厚度"].identifier
                thickness_prop = getattr(target_modifier.properties.inputs, thickness_identifier)

            # 清除旧驱动
            try:
                if block:
                    # Blender 5.2：驱动需添加在输入属性对象上，属性名为 value
                    thickness_prop.driver_remove("value")  # 移除旧驱动
                else:
                    target_modifier.driver_remove("thickness")  # 移除旧驱动
            except:
                pass

            # 清理 Blender 5.1 及更早版本残留的旧式驱动，
            # 旧路径形如 modifiers["修改器名"]["Input_1"]，在 5.2 中已失效
            if block and active_obj.animation_data:
                legacy_path = target_modifier.path_from_id() + '["' + thickness_identifier + '"]'
                for legacy_fcurve in list(active_obj.animation_data.drivers):
                    if legacy_fcurve.data_path == legacy_path:
                        try:
                            active_obj.animation_data.drivers.remove(legacy_fcurve)
                        except:
                            pass

            # 获取物体
            obj_a1 = A1
            obj_a2 = A2
            if not obj_a1 or not obj_a2:
                print("未找到 A1 或 A2 物体。")
                return

            if block:
                # Blender 5.2：为几何节点输入的 value 属性添加驱动器
                fcurve = thickness_prop.driver_add("value")
                driver = fcurve.driver
            else:
                # 为实体化修改器的 thickness 属性添加驱动器
                fcurve = target_modifier.driver_add("thickness")
                driver = fcurve.driver

            # 添加一个变量
            var = driver.variables.new()
            var.name = "distance"
            var.type = 'LOC_DIFF'

            # 设置变量的目标对象
            target = var.targets[0]
            target.id = obj_a1
            target.transform_space = 'WORLD_SPACE'  # 设置为世界空间

            target = var.targets[1]
            target.id = obj_a2
            target.transform_space = 'WORLD_SPACE'  # 设置为世界空间

            # 设置驱动器表达式
            driver.expression = "distance"

            # 删除 F 曲线的所有修改器
            for mod in fcurve.modifiers:
                fcurve.modifiers.remove(mod)

            # 删除 F 曲线的所有关键帧
            fcurve.keyframe_points.clear()

            '''最小值'''
            # 添加关键帧 0，值为 0.08
            kf0 = fcurve.keyframe_points.insert(frame=A3, value=A4)
            # 设置插值方式为线性
            kf0.interpolation = 'LINEAR'

            '''最大值'''
            # 添加关键帧 20，值为 0.5
            kf20 = fcurve.keyframe_points.insert(frame=A5, value=A6)
            # 设置插值方式为线性
            kf20.interpolation = 'LINEAR'

        if mmi.rfd_ghu:
            Obj1 = context.active_object

            if mmi.Track_the_camera.name in bpy.data.objects:
                obj_b1 = mmi.Track_the_camera

                # 查找目标集合
                target_collection = None
                for collection in bpy.data.collections:
                    if mmi.Face_positioning.name in collection.objects:
                        target_collection = collection
                        break

                if target_collection:
                    # 生成基础名称（不含序号）
                    base_name = target_collection.name + "描边追踪"

                    # 创建正则匹配模式
                    pattern = re.compile(r'^{}(\.\d+)?$'.format(re.escape(base_name)))

                    # 仅遍历目标集合中的物体
                    to_remove = []
                    for obj in target_collection.objects:
                        if pattern.match(obj.name):
                            to_remove.append(obj)

                    # 删除匹配的物体
                    for obj in to_remove:
                        bpy.data.objects.remove(obj, do_unlink=True)

                    # 创建新空物体（此时名称不会冲突）
                    empty_obj = bpy.data.objects.new(base_name, None)
                    target_collection.objects.link(empty_obj) # 放入集合

                # 遍历场景中的所有相机
                for camera in bpy.data.cameras:
                    # 为新创建的空物体添加子级约束
                    child_constraint = empty_obj.constraints.new(type='CHILD_OF')
                    # 设置约束的目标物体为当前相机
                    child_constraint.target = bpy.data.objects.get(camera.name)
                    child_constraint.name = camera.name

                    # 激活空物体
                    bpy.ops.object.select_all(action='DESELECT')
                    bpy.context.view_layer.objects.active = empty_obj
                    # 选择空物体
                    empty_obj.select_set(True)
                    # 清除子级约束的逆矩阵
                    bpy.ops.constraint.childof_clear_inverse(constraint=child_constraint.name, owner='OBJECT')

                i = 0
                # 遍历所有标记
                for marker in scene.timeline_markers:
                    # 检查标记是否与相机关联
                    if marker.camera:
                        # 输出标记的名称、帧位置和关联的相机
                        print(f"标记名称: {marker.name}")
                        print(f"帧位置: {marker.frame}")
                        print(f"关联相机: {marker.camera.name}")
                        obj = empty_obj
                        # 遍历对象的所有约束
                        for constraint1 in obj.constraints:
                            # 匹配与标记相机同名的约束
                            if constraint1.name == marker.camera.name:
                                print(f"激活约束 - {constraint1.name}")

                                # 设置当前约束的权重为1（完全激活）
                                constraint1.influence = 1
                                # 插入关键帧（默认贝塞尔插值）
                                constraint1.keyframe_insert(data_path="influence", frame=marker.frame)

                                # 检查动画数据是否存在（防止空指针）
                                if obj.animation_data and obj.animation_data.action:
                                    # 遍历所有动画曲线
                                    for fcurve in obj.animation_data.action.fcurves:
                                        # 通过数据路径匹配目标曲线
                                        # path_from_id()生成形如 "constraints["ConstraintName"].influence" 的路径
                                        if fcurve.data_path == constraint1.path_from_id("influence"):
                                            # 遍历该曲线的所有关键帧点
                                            for keyframe in fcurve.keyframe_points:
                                                # 匹配当前帧的关键帧（x坐标为帧号）
                                                if keyframe.co.x == marker.frame:
                                                    # 设置插值模式为常量（阶梯式变化）
                                                    keyframe.interpolation = 'CONSTANT'
                                                    break  # 找到后退出循环

                                # 处理其他约束（非当前标记相机关联的约束）
                                for constraint2 in obj.constraints:
                                    if constraint2.name != marker.camera.name:
                                        print(f"禁用约束 - {constraint2.name}")
                                        # 设置其他约束权重为0（完全禁用）
                                        constraint2.influence = 0
                                        # 插入关键帧
                                        constraint2.keyframe_insert(data_path="influence", frame=marker.frame)

                                        # 重复相同的插值模式设置流程
                                        if obj.animation_data and obj.animation_data.action:
                                            for fcurve in obj.animation_data.action.fcurves:
                                                if fcurve.data_path == constraint2.path_from_id("influence"):
                                                    for keyframe in fcurve.keyframe_points:
                                                        if keyframe.co.x == marker.frame:
                                                            keyframe.interpolation = 'CONSTANT'
                                                            break
                        print("-" * 20)
                        i = i + 1
                print(i)

                # 激活物体
                bpy.ops.object.select_all(action='DESELECT')
                bpy.context.view_layer.objects.active = Obj1
                # 选择物体
                Obj1.select_set(True)
                # 执行操作
                add_driver_to_solidify(mmi.Face_positioning, empty_obj, mmi.minimum_value_meters, mmi.minimum_Thickness, mmi.utmost_value_meters, mmi.utmost_Thickness)
            else:
                print("未找到名为 '追踪相机' 的物体。")
        else:
            # 执行操作
            add_driver_to_solidify(mmi.Face_positioning,mmi.Track_the_camera, mmi.minimum_value_meters, mmi.minimum_Thickness, mmi.utmost_value_meters, mmi.utmost_Thickness)

        return {'FINISHED'}

class FixAMDgraphicscardsynthesizerbug(bpy.types.Operator):
    '''Fix AMD graphics card synthesizer bug'''
    bl_idname = "object.fix_synthesizer_ops"
    bl_label = "Fix AMD graphics card synthesizer bug"
    # 确保在操作之前备份数据，用户撤销操作时可以恢复
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):

        def process_nodes(nodes):
            for node in nodes:
                if node.type == 'TEX_IMAGE' and node.name != 'Shadow_Ramp':
                    node.interpolation = 'Smart'
                elif node.type == 'GROUP':
                    # 递归处理节点组内的节点
                    group_nodes = node.node_tree.nodes
                    process_nodes(group_nodes)

        # 获取场景中的所有对象
        all_objects = bpy.context.scene.objects

        for obj in all_objects:
            if obj.type == 'MESH':
                # 检查对象是否有材质插槽
                if obj.material_slots:
                    # 遍历对象的所有材质
                    for material_slot in obj.material_slots:
                        material = material_slot.material
                        if material and material.use_nodes:
                            nodes = material.node_tree.nodes
                            process_nodes(nodes)

        return {'FINISHED'}

# 边缘预览
class EdgePreviewOperator(bpy.types.Operator):
    '''Edge Preview'''
    bl_idname = "object.edge_preview_ops"
    bl_label = "Edge Preview"
    # 确保在操作之前备份数据，用户撤销操作时可以恢复
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.active_object is not None and context.active_object.type == "MESH"

    def execute(self, context):
        # 获取当前运行的Py文件的路径
        current_file_path = __file__
        # 获取当前Py文件所在的文件夹路径
        new_path = os.path.dirname(current_file_path)
        # 将当前文件夹路径和文件名组合成完整的文件路径
        file = 'bhp.blend'
        new_file_path = os.path.join(new_path, file)

        # 检查当前场景是否存在名为 "MMI-自动描边" 的几何节点组
        if not "MMI-自动描边" in bpy.data.node_groups:
            print("几何节点组 'MMI-自动描边' 不存在。")
            # 从Blend文件中追加节点组
            with bpy.data.libraries.load(new_file_path, link=False) as (data_from, data_to):
                data_to.node_groups = [name for name in data_from.node_groups if name == "MMI-自动描边"]

        # 检查当前场景是否存在名为 "MMI-Edge-Preview" 的材质节点组
        if not "MMI-Edge-Preview" in bpy.data.node_groups:
            print("材质节点组 'MMI-Edge-Preview' 不存在。")
            # 从Blend文件中追加节点组
            with bpy.data.libraries.load(new_file_path, link=False) as (data_from, data_to):
                data_to.node_groups = [name for name in data_from.node_groups if name == "MMI-Edge-Preview"]

        obj_A = context.active_object # 获取当前活动的物体

        obj_A_material_name = []

        e = True  # 标记是否存在'mmi-edge|'的前缀

        # 遍历物体所有的材质槽
        for material_slot in obj_A.material_slots:

            # 是否存在'mmi-edge|'的前缀
            if material_slot.material.name.startswith('mmi-edge|'):
                e = False
                break  # 找到匹配的材质槽，退出循环

            # 获取当前材质槽的材质
            material = material_slot.material
            # 获取材质的名称
            material_name = material.name
            # 将材质名称添加到列表中
            obj_A_material_name.append(material_name)

        # 材质数量
        obj_A_material_number = len(obj_A_material_name)
        print(f"物体 {obj_A.name} 的材质数量为 {obj_A_material_number}")

        # 新建材质
        for material_name in obj_A_material_name:

            if e:
                new_material = bpy.data.materials.new(name='mmi-edge|' + material_name)
                new_material.use_nodes = True  # 启用节点
            else:
                new_material = bpy.data.materials.get('mmi-edge|' + material_name)
                new_material.use_nodes = True

            new_material.surface_render_method = 'BLENDED' # 启用混合渲染

            # 删除所有的节点
            for node in new_material.node_tree.nodes:
                new_material.node_tree.nodes.remove(node)

            # 获取节点树
            node_tree = new_material.node_tree

            t = ['颜2', '面2', '二重', '睫', '口舌','齿', '眉', '白目', '目', '星目', '口', '舌', '眉睫', '目影', '目光', '瞳孔', '睫眉']

            u = 1

            for i in t:
                material_name_A1 = material_name.split('.', -1)[0]
                if i == material_name_A1:
                    u = 0
                elif '+' in material_name_A1:
                    u = 0

            # 节点组
            node_group = node_tree.nodes.new(type='ShaderNodeGroup')
            node_group.node_tree = bpy.data.node_groups["MMI-Edge-Preview"]
            node_group.location = (0, 0)
            node_group.inputs['Alpha'].default_value = u

            # 材质输出
            node_output = node_tree.nodes.new(type='ShaderNodeOutputMaterial')
            node_output.location = (200, 0)

            # 链接节点
            links = node_tree.links
            link = links.new(node_group.outputs[0], node_output.inputs[0])

            # 新建材质槽
            if e:
                new_material_slot = obj_A.data.materials.append(new_material)

        # 几何节点
        if not 'MMI-边缘预览' in obj_A.modifiers:

            new_modifiers = obj_A.modifiers.new(name="MMI-边缘预览", type='NODES')
            new_modifiers.node_group = bpy.data.node_groups["MMI-自动描边"]

            inputs = new_modifiers.node_group.interface.items_tree

            # Blender 5.2：几何节点输入改为通过 properties.inputs.<标识符>.value 访问
            gn_inputs = new_modifiers.properties.inputs
            getattr(gn_inputs, inputs["描边厚度"].identifier).value = 0.1
            getattr(gn_inputs, inputs["翻转面"].identifier).value = True
            getattr(gn_inputs, inputs["材质偏移"].identifier).value = obj_A_material_number
            getattr(gn_inputs, inputs["描边合并"].identifier).value = 0.0001

            bpy.ops.mmi.update_stroke_list()

        return {'FINISHED'}

# 撤销边缘预览
class RevokeEdgePreviewOperator(bpy.types.Operator):
    '''revoke Edge Preview'''
    bl_idname = "object.revoke_edge_preview_ops"
    bl_label = ""
    # 确保在操作之前备份数据，用户撤销操作时可以恢复
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.active_object is not None and context.active_object.type == "MESH"

    def execute(self, context):

        obj_A = bpy.context.active_object  # 获取当前活动的物体

        # 收集需要删除的材质槽索引
        slots_to_remove = []
        for idx, material_slot in enumerate(obj_A.material_slots):
            material = material_slot.material
            if material and material.name.startswith("mmi-edge|"):
                slots_to_remove.append(idx)

        # 按逆序删除材质槽
        for idx in sorted(slots_to_remove, reverse=True):
            # 设置活动材质槽为当前索引
            obj_A.active_material_index = idx
            # 使用操作符删除活动材质槽
            bpy.ops.object.material_slot_remove()

        # 删除材质数据块
        materials_to_remove = [mat for mat in bpy.data.materials
                               if mat.name.startswith("mmi-edge|") and mat.users == 0]

        for material in materials_to_remove:
            bpy.data.materials.remove(material)

        # 遍历物体的所有修改器
        for modifier in obj_A.modifiers:
            # 检查修改器的名称是否为 "MMI-边缘预览"
            if modifier.name == "MMI-边缘预览":
                # 移除修改器
                obj_A.modifiers.remove(modifier)

        bpy.ops.mmi.update_stroke_list()

        return {'FINISHED'}

# MMD边缘预览转换到MMI
class MMD2MMIEdgePreviewOperator(bpy.types.Operator):
    '''MMD边缘预览转换到MMI'''
    bl_idname = "object.mmd2mmi_edge_preview_ops"
    bl_label = "Convert to MMI"
    # 确保在操作之前备份数据，用户撤销操作时可以恢复
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.active_object is not None and context.active_object.type == "MESH"

    def execute(self, context):

        # 获取当前运行的Py文件的路径
        current_file_path = __file__
        # 获取当前Py文件所在的文件夹路径
        new_path = os.path.dirname(current_file_path)
        # 将当前文件夹路径和文件名组合成完整的文件路径
        file = 'bhp.blend'
        new_file_path = os.path.join(new_path, file)

        # 检查当前场景是否存在名为 "MMI-自动描边" 的几何节点组
        if not "MMI-自动描边" in bpy.data.node_groups:
            print("几何节点组 'MMI-自动描边' 不存在。")
            # 从Blend文件中追加节点组
            with bpy.data.libraries.load(new_file_path, link=False) as (data_from, data_to):
                data_to.node_groups = [name for name in data_from.node_groups if name == "MMI-自动描边"]

        # 检查当前场景是否存在名为 "MMI-Edge-Preview" 的材质节点组
        if not "MMI-Edge-Preview" in bpy.data.node_groups:
            print("材质节点组 'MMI-Edge-Preview' 不存在。")
            # 从Blend文件中追加节点组
            with bpy.data.libraries.load(new_file_path, link=False) as (data_from, data_to):
                data_to.node_groups = [name for name in data_from.node_groups if name == "MMI-Edge-Preview"]

        active_obj = bpy.context.active_object # 获取当前活动的物体

        # 获取mmd_edge_preview实体化修改器
        thickness_rounded = 0
        material_offsets = 0
        use_flip_normals = True

        for modifier in active_obj.modifiers:
            if modifier.type == 'SOLIDIFY' and modifier.name == 'mmd_edge_preview':
                thickness_rounded = round(modifier.thickness, 2)
                material_offsets = modifier.material_offset
                use_flip_normals = modifier.use_flip_normals
                active_obj.modifiers.remove(modifier)
                break

        # 检查物体是否有材质
        if hasattr(active_obj.data, 'materials') and active_obj.data.materials:
            for mat_slot in active_obj.material_slots:
                mat = mat_slot.material

                # 节点树
                mmd_node_tree = mat.node_tree

                if mat and mat.name.startswith("mmd_edge."):
                    # 移除前缀并构造新名称
                    new_name = "mmi-edge|" + mat.name[len("mmd_edge."):]

                    # 检查新名称是否已存在
                    if new_name not in bpy.data.materials:
                        mat.name = new_name
                        mat.diffuse_color = (1.0, 1.0, 1.0, 1.0)  # 白色

                        mmd_node_edge = mmd_node_tree.nodes.get("mmd_edge_preview") # 获取节点

                        # 获取名为 "MMDEdgePreview" 节点组的Color输入
                        MMD_color_input = mmd_node_edge.inputs.get("Color").default_value

                        # 获取名为 "MMDEdgePreview" 节点组的Alpha输入
                        MMD_alpha_input = mmd_node_edge.inputs.get("Alpha").default_value

                        del_nodes = []

                        # 删除所有的节点，完成后再删掉
                        for node in mmd_node_tree.nodes:
                            del_nodes.append(node)

                        # 节点组
                        node_group = mmd_node_tree.nodes.new(type='ShaderNodeGroup')
                        node_group.name = "MMI-Edge-Preview"
                        node_group.node_tree = bpy.data.node_groups["MMI-Edge-Preview"]
                        node_group.location = (0, 0)

                        # 材质输出
                        mmi_ol = mmd_node_tree.nodes.new(type='ShaderNodeOutputMaterial')
                        mmi_ol.location = (200, 0)

                        # 链接节点
                        links = mmd_node_tree.links
                        link = links.new(node_group.outputs[0], mmi_ol.inputs[0])

                        # 设置节点组的输入值
                        node_group.inputs['Alpha'].default_value = MMD_alpha_input
                        node_group.inputs['Color'].default_value = MMD_color_input

                        # 删除列表中所有的节点
                        for node in del_nodes:
                            mmd_node_tree.nodes.remove(node)

        idx_list = []  # 用于存储需要删除的索引

        # 遍历材质槽索引
        for idx in range(len(active_obj.material_slots)):
            mat_slot = active_obj.material_slots[idx]
            mat = mat_slot.material
            if 'disabled' in mat.name:
                idx_list.append(idx)

        for idx in idx_list:
            mat_slot = active_obj.material_slots[idx]
            material = mat_slot.material  # 获取材质

            # 节点树
            mmd_node_tree = material.node_tree

            # 获取节点
            mmi_node_edge = mmd_node_tree.nodes.get("MMI-Edge-Preview")

            # 获取名为 "MMI-Edge-Preview" 节点组的Color输入
            MMI_color_input = mmi_node_edge.inputs.get("Color").default_value

            # 获取名为 "MMI-Edge-Preview" 节点组的Alpha输入
            MMI_alpha_input = mmi_node_edge.inputs.get("Alpha").default_value

            # 获取原名称
            old_idx = idx - material_offsets
            old_mat_slot = active_obj.material_slots[old_idx]
            old_mat_name = old_mat_slot.material.name
            # 新建材质
            new_material = bpy.data.materials.new(name='mmi-edge|' + old_mat_name)
            # 启用节点
            new_material.use_nodes = True
            # 启用背面剔除
            new_material.use_backface_culling = True
            # 更换材质
            active_obj.material_slots[idx].material = new_material

            # 删除所有的节点
            for node in new_material.node_tree.nodes:
                new_material.node_tree.nodes.remove(node)

            # 节点组
            node_group = new_material.node_tree.nodes.new(type='ShaderNodeGroup')
            node_group.name = "MMI-Edge-Preview"
            node_group.node_tree = bpy.data.node_groups["MMI-Edge-Preview"]
            node_group.location = (0, 0)
            # 材质输出
            mmi_shader = new_material.node_tree.nodes.new(type='ShaderNodeOutputMaterial')
            mmi_shader.location = (200, 0)
            # 链接节点
            links = new_material.node_tree.links
            link = links.new(node_group.outputs[0], mmi_shader.inputs[0])
            # 设置节点组的输入值
            node_group.inputs['Alpha'].default_value = MMI_alpha_input
            node_group.inputs['Color'].default_value = MMI_color_input

        # 遍历物体的所有修改器
        for modifier in active_obj.modifiers:
            # 检查修改器的名称是否为 "MMI-边缘预览"
            if modifier.name == "MMI-边缘预览":
                return {'FINISHED'}

        # 新建修改器
        new_modifiers = active_obj.modifiers.new(name="MMI-边缘预览", type='NODES')
        new_modifiers.node_group = bpy.data.node_groups["MMI-自动描边"]

        inputs = new_modifiers.node_group.interface.items_tree

        # Blender 5.2：几何节点输入改为通过 properties.inputs.<标识符>.value 访问
        gn_inputs = new_modifiers.properties.inputs
        getattr(gn_inputs, inputs["描边厚度"].identifier).value = thickness_rounded
        getattr(gn_inputs, inputs["翻转面"].identifier).value = use_flip_normals
        getattr(gn_inputs, inputs["材质偏移"].identifier).value = material_offsets
        getattr(gn_inputs, inputs["描边合并"].identifier).value = 0.0001

        bpy.ops.mmi.update_stroke_list()

        return {'FINISHED'}


class MatchingmaterialsMMDmodelOperator(bpy.types.Operator):
    '''Matching materials to MMD model'''
    bl_idname = "object.matching_materials_mmd_model_ops"
    bl_label = "Matching materials to MMD model"
    # 确保在操作之前备份数据，用户撤销操作时可以恢复
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.active_object is not None and context.active_object.type == "MESH"

    # 打开文件选择器
    directory: bpy.props.StringProperty(
        subtype='DIR_PATH',
    )
    filter_folder: bpy.props.BoolProperty(
        default=True,
        options={'HIDDEN'}
    )
    filter_image: bpy.props.BoolProperty(
        default=True,
        options={'HIDDEN'}
    )

    def execute(self, context):

        scene = context.scene
        mmi = context.object.mmi

        mmi.filepath = self.directory

        bpy.ops.object.genshin_node_ops()  # 执行genshin_node_ops

        png_name_idx = {}  # 图像文件的名称和材质槽索引
        image_types = {}  # 图像名称和模式
        operation_Mode = {}  # 操作模式

        # 获取当前活动对象
        obj = bpy.context.active_object

        print(self.directory)

        # 遍历材质槽
        for slot in obj.material_slots:
            mat = slot.material

            if mat and mat.use_nodes:  # 检查材质是否使用节点
                nodes = mat.node_tree.nodes

                # 查找名为'mmd_base_tex'的图像纹理节点
                tex_node = nodes.get("mmd_base_tex")

                if tex_node and tex_node.type == 'TEX_IMAGE':
                    if tex_node.image:
                        # 获取图像文件的名称
                        png_name_idx[slot.slot_index] = tex_node.image.name
                    else:
                        print(f"材质 '{mat.name}' 中'mmd_base_tex'节点未关联图像")
                else:
                    print(f"材质 '{mat.name}' 中未找到'mmd_base_tex'图像纹理节点")

        for i in scene.mmi_images:
            image_types[i.image.name] = i.image_type

        for key, value in png_name_idx.items():
            for key1, value1 in image_types.items():
                if value == key1:
                    operation_Mode[key] = value1

        # 遍历材质槽
        for slot in obj.material_slots:
            for key, value in operation_Mode.items():
                if slot.slot_index == key:
                    obj.active_material_index = key  # 设置当前材质槽索引
                    if value == "FACE":
                        bpy.ops.object.genshin_face_ops()
                    if value == "HAIR":
                        bpy.ops.object.genshin_presets_ops()
                    if value == "BODY":
                        bpy.ops.object.genshin_body_ops()
                    if value == 'MANUAL':
                        bpy.ops.object.genshin_manual_ops()
                    if value == "SKIP":
                        continue # 跳过匹配
                    print(f"材质 '{slot.material.name}' 对应的模式为 '{value}'")
        return {'FINISHED'}

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

# 旧版命名转换为新版命名
class ConvertOldNameToNewNameOperator(bpy.types.Operator):
    '''Convert old name to new name'''
    bl_idname = "object.convert_old_name_to_new_name_ops"
    bl_label = "Convert old name to new name"
    # 确保在操作之前备份数据，用户撤销操作时可以恢复
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):

        old_names = ['AA', 'AAA', 'AAAA', 'AAAAA', '脸部定位']

        for obj in bpy.data.objects:

            if obj.name == old_names[0]:
                obj.name = mmi_object_name["MMI_AA"]

            if obj.name == old_names[1]:
                obj.name = mmi_object_name["MMI_AAA"]

            if obj.name == old_names[2]:
                obj.name = mmi_object_name["MMI_AAAA"]

            if obj.name == old_names[3]:
                obj.name = mmi_object_name["MMI_AAAAA"]

            if obj.name == old_names[4]:
                obj.name = "MMI_脸部定位"

        return {'FINISHED'}

# 批量处理当前目录的.blend文件
class blender_batch_process_operator(bpy.types.Operator):
    """Convert all .blend files to new naming format"""
    bl_idname = "object.blender_batch_process_ops"
    bl_label = "Convert all .blend files to new naming format"
    # 确保在操作之前备份数据，用户撤销操作时可以恢复
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):

        # 获取当前目录
        current_dir = bpy.path.abspath("//")

        # 遍历当前目录下的所有.blend文件
        for file in os.listdir(current_dir):
            if file.endswith(".blend"):
                # 构建.blend文件的完整路径
                blend_file_path = os.path.join(current_dir, file)

                # 加载.blend文件
                bpy.ops.wm.open_mainfile(filepath=blend_file_path)

                # 执行转换旧名新名操作
                bpy.ops.object.convert_old_name_to_new_name_ops()

                # 执行规格化节点组名称操作
                bpy.ops.object.normalize_node_group_name_ops()

                # 执行添加材质色调映射节点操作
                bpy.ops.object.add_tone_mapping_node_ops(auto_mode=True)

                # 执行钳制兰伯特阴影操作
                bpy.ops.mmi.clamp_lambertian_shadow(auto_mode=True)
                
                # 执行删除未引用的数据操作
                bpy.ops.outliner.orphans_purge()

                # 保存.blend文件
                bpy.ops.wm.save_mainfile()

                print(f"已处理文件: {file}")

        return {'FINISHED'}

# 下载预设
class DownloadPresetsOperator(bpy.types.Operator):
    '''Download presets'''
    bl_idname = "object.download_presets_ops"
    bl_label = "Download presets"
    bl_description = "下载预设，点击后会打开MMI仓库，如果打不开，请用加速器（如Watt Toolkit）打开"
    # 确保在操作之前备份数据，用户撤销操作时可以恢复
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        # 打开网页
        URL = "https://github.com/XiaoFFGe/MikuMikuImport/tree/main/"

        webbrowser.open(URL)

        return {'FINISHED'}

# 删除模型顶点
class DeleteModelVerticesOperator(bpy.types.Operator):
    '''Delete model vertices'''
    bl_idname = "object.delete_model_vertices_ops"
    bl_label = "Delete model vertices"
    # 确保在操作之前备份数据，用户撤销操作时可以恢复
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        obj = context.active_object
        if obj and obj.type == 'MESH':
            # 编辑模式
            bpy.ops.object.mode_set(mode='EDIT')
            # 删除顶点
            bpy.ops.mesh.select_all(action='SELECT')
            bpy.ops.mesh.delete(type='VERT')

            # 切换回对象模式
            bpy.ops.object.mode_set(mode='OBJECT')

        return {'FINISHED'}

# 规格化节点组名称
class NormalizeNodeGroupNameOperator(bpy.types.Operator):
    '''Normalize node group name'''
    bl_idname = "object.normalize_node_group_name_ops"
    bl_label = "Normalize node group name"
    # 确保在操作之前备份数据，用户撤销操作时可以恢复
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):

        def collect_node_groups_recursive(node_tree, collected):
            """递归收集节点树中的所有节点组"""
            for node in node_tree.nodes:
                if node.type == 'GROUP':
                    group = node.node_tree
                    if group and group not in collected:
                        collected.append(node)
                        # 递归进入节点组内部
                        collect_node_groups_recursive(group, collected)
            return collected

        # 遍历所有对象
        for obj in bpy.data.objects:
            if obj.type == 'MESH':
                for slot in obj.material_slots:
                    mat = slot.material
                    if mat and mat.node_tree:

                        # 找到该材质的所有节点组（含嵌套）
                        node_groups = collect_node_groups_recursive(mat.node_tree, [])

                        for node in node_groups:
                            print(f"材质: {mat.name}, 节点组: {node.name}")
                            # 规格化节点名称
                            node.name = node.node_tree.name

        return {'FINISHED'}

# 给当前模型添加色调映射节点
class AddToneMappingNode(bpy.types.Operator):
    '''Add tone mapping node'''
    bl_idname = "object.add_tone_mapping_node_ops"
    bl_label = "Add material tone mapping node"
    # 确保在操作之前备份数据，用户撤销操作时可以恢复
    bl_options = {'REGISTER', 'UNDO'}

    # 自动模式
    auto_mode : bpy.props.BoolProperty(default=False, name="自动模式")

    def execute(self, context):

        # 获取当前运行的Py文件的路径
        current_file_path = __file__
        # 获取当前Py文件所在的文件夹路径
        new_path = os.path.dirname(current_file_path)
        # 将当前文件夹路径和文件名组合成完整的文件路径
        file = 'bhp.blend'
        new_file_path = os.path.join(new_path, file)

        def Additional_actions(A, B, filepath):
            collection_name = A

            with bpy.data.libraries.load(filepath, link=False) as (data_from, data_to):
                if B == 'Collection':
                    if collection_name in data_from.collections:
                        data_to.collections = [collection_name]
                elif B == 'NodeTree':
                    if collection_name in data_from.node_groups:
                        data_to.node_groups = [collection_name]

        def node_exists(node_tree, node_name):
            """检查节点树中是否存在指定名称的节点"""
            for node in node_tree.nodes:
                if node.name == node_name:
                    return True
            return False

        def node_group_exists(node_group_name):
            """检查blend文件是否存在指定名称的节点组"""
            for group in bpy.data.node_groups:
                if group.name == node_group_name:
                    return True
            return False

        if self.auto_mode:
            obj = bpy.data.objects.get(mmi_object_name['MMI_AAAA'])
            if not obj:
                print("未找到MMI_Mesh对象")
                return {'CANCELLED'}

        else:
            obj = context.active_object

        def find_light_node_group(node_tree):
            """递归寻找名为 "光颜色" 的节点组"""

            for node1 in node_tree.nodes:
                if node1.name == '光颜色':
                    return node1

                if node1.type == 'GROUP':
                    group = node1.node_tree
                    if group:
                        # 递归进入节点组内部，并捕获返回值
                        result = find_light_node_group(group)
                        if result:
                            return result
            return None

        if obj and obj.type == 'MESH':
            for slot in obj.material_slots:
                mat = slot.material
                if mat and mat.node_tree:

                    light_node = find_light_node_group(mat.node_tree)

                    if light_node:

                        # 检查是否已存在材质色调映射节点
                        if node_exists(light_node.node_tree, "材质色调映射"):
                            print(f"材质: {mat.name}, 材质色调映射节点已存在")

                            for node in light_node.node_tree.nodes:
                                if node.name == "材质色调映射":
                                    node.inputs[1].default_value = 0.0
                                    break

                            return {'FINISHED'}
                        else:
                            # 检查节点组是否存在
                            if not node_group_exists("材质色调映射"):
                                Additional_actions("材质色调映射", "NodeTree", new_file_path)

                        print(f"材质: {mat.name}, 节点组: {light_node.name}")

                        node_tree = light_node.node_tree # 获取光颜色节点组的节点树

                        for node in node_tree.nodes:
                            if node.type == 'GROUP_OUTPUT':
                                input_socket = node.inputs[0] # 获取组输出节点的输入插口
                                if input_socket.links:

                                    old_link = input_socket.links[0] # 获取组输出节点的第一个链接
                                    from_socket = old_link.from_socket # 获取旧链接的起始插口
                                    to_socket = old_link.to_socket # 获取旧链接的结束插口

                                    # 获取上游节点和输出节点本身
                                    from_node = from_socket.node  # 原输出节点
                                    to_node = to_socket.node  # GROUP_OUTPUT 节点

                                    # 创建新节点
                                    new_node = node_tree.nodes.new(type='ShaderNodeGroup')
                                    new_node.name = "材质色调映射"
                                    new_node.node_tree = bpy.data.node_groups["材质色调映射"]

                                    new_node.inputs[1].default_value = 0.0

                                    # 将新节点放置在两个节点的中间
                                    mid_x = (from_node.location.x + to_node.location.x) / 2
                                    mid_y = (from_node.location.y + to_node.location.y) / 2
                                    new_node.location = (mid_x, mid_y)

                                    # 移除旧链接，建立新链接
                                    node_tree.links.remove(old_link)
                                    node_tree.links.new(from_socket, new_node.inputs[0])
                                    node_tree.links.new(new_node.outputs[0], to_socket)

                                break  # 处理完第一个就跳出

        return {'FINISHED'}

# 钳制兰伯特阴影
class Make_Lambertian_Shadow(bpy.types.Operator):
    bl_idname = "mmi.clamp_lambertian_shadow"
    bl_label = "Clamp Lambertian Shadow"
    bl_description = "Clamp Lambertian Shadow"

    bl_options = {'REGISTER', 'UNDO'}

    # 自动模式
    auto_mode : bpy.props.BoolProperty(default=False, name="自动模式")

    def execute(self, context):

        def find_light_node_group(node_tree, node_name):
            """递归寻找名为 node_name 的节点组"""

            for node1 in node_tree.nodes:
                if node1.name == node_name and node1.type == 'GROUP':
                    return node1

                if node1.type == 'GROUP':
                    group = node1.node_tree
                    if group:
                        # 递归进入节点组内部，并捕获返回值
                        result = find_light_node_group(group, node_name)
                        if result:
                            return result
            return None

        # 自动模式
        if self.auto_mode:
            obj = bpy.data.objects.get(mmi_object_name['MMI_AAAA'])
        else:
            obj = context.active_object

        if not obj or obj.type != 'MESH':
            return {'CANCELLED'}

        for slot in obj.material_slots:
            mat = slot.material
            if mat and mat.node_tree:
                light_node = find_light_node_group(mat.node_tree, "Shadow_Ramp采样")
                if light_node:

                    for node in light_node.node_tree.nodes:
                        if node.type == 'GROUP' and node.name == '兰伯特':
                            for node2 in node.node_tree.nodes:
                                if node2.type == 'MATH' and node2.operation == 'MULTIPLY_ADD':
                                    node2.use_clamp = True
                                    node2.name = "Lambertian Shadow"

        return {'FINISHED'}
